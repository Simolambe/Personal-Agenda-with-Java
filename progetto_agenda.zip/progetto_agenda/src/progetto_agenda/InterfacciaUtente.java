package progetto_agenda;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 * 
 * The InterfacciaUtente class represents the user interface for the agenda management program.
 */

public class InterfacciaUtente {

	
	
	
	public static void main(String[] args) {
	
	}
}