package progetto_agenda;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**

This class represents a manager for agendas.

A manager for agendas can add, delete and view agendas, as well as read and write appointments from and to a file.
*/

public class GestoreAgende{

	private HashMap<String,Agenda> lista_agende;
	
	/**

	Constructs a new manager for agendas.
	*/
	
	public GestoreAgende() {
		this.lista_agende = new HashMap<String,Agenda>();
	}
	
	/**

	Adds a new agenda with the specified name to the manager.
	@param nome the name of the new agenda
	@throws IllegalArgumentException if there already exists an agenda with the same name
	*/
	
	public void aggiungiAgenda(String nome) {
		if(lista_agende.containsKey(nome)) {
			throw new IllegalArgumentException("\nNon � possibile aggiungere un'agenda con lo stesso nome"); 
		}
		Agenda a = new Agenda(nome);
		lista_agende.put(nome,a);	
	}

	/**
	Writes the contents of an Agenda object to a file.
	@param nomeFile The name of the file to write to
	@param a The Agenda object to write
	@throws IOException If an error occurs while writing to the file
	*/
	

	    public void scriviSuFile(String nomeFile, Agenda a) throws IOException {
	        File file = new File(nomeFile);
	        if (!file.exists()) {
	            file.createNewFile();
	        }
	        FileWriter writer = new FileWriter(file);
	        writer.write(a.toString());
	        writer.close();
	    }
	
	
	/**
	Reads an appointment from a file.
	@param nomeFile The name of the file to read the appointment from.
	@return The appointment read from the file.
	@throws IOException if an error occurs while reading from the file.
	*/

	    public void leggiDaFile(String nomeFile) throws IllegalArgumentException {
	        File file = new File(nomeFile);
	        if (!file.exists()) {
	            throw new IllegalArgumentException("\nIl nome del file che hai inserito non esiste");
	        }
	    }
	
    /**
    Removes an agenda from the list of agendas with the given name.
    @param nome The name of the agenda to remove.
    @throws IllegalArgumentException if an agenda with the given name does not exist in the list.
    */
    
	public void eliminaAgenda(String nome) {
		if(!lista_agende.containsKey(nome)) 
			throw new IllegalArgumentException("\nL'agenda che vuoi eliminare non esiste, controlla di aver inserito il nome corretto"); 
		lista_agende.remove(nome);
	}
	
	/**

	Displays the appointments of an Agenda sorted by date.
	@param a The Agenda to be displayed.
	*/
	
	public void visualizzaPerData(Agenda a) {
		ArrayList<Appuntamento> lista = a.getAppuntamenti();
		Collections.sort(lista, new ConfrontoDate());
		System.out.println(lista);
	}

	
	public Agenda getAgenda(String nome) {
		return lista_agende.get(nome);
	}

	@Override
	public String toString() {
		return "GestoreAgende [lista_agende=" + lista_agende + "]";
	}
		
	
}
