package progetto_agenda;

import java.util.Comparator;

/**
 * 
The ConfrontoDate class implements the Comparator interface and is used to compare Appuntamento objects based on their date.
*/

public class ConfrontoDate implements Comparator<Appuntamento>{

	@Override
	public int compare(Appuntamento o1, Appuntamento o2) {
		
		if(o1.getData().isAfter(o2.getData()))
			return 1;
		else if(o1.getData().isBefore(o2.getData()))
			return -1;
		else
			return 0;
	}

}
