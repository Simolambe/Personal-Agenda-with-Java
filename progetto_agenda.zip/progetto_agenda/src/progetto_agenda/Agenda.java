package progetto_agenda;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 * Class that implements an Agenda to store appointments.
 */

public class Agenda implements Iterable<Appuntamento>{

	private String nome;
	private ArrayList<Appuntamento> appuntamenti;
	Scanner sc = new Scanner(System.in);

	/**
	 * Constructor to create an Agenda with the given name.
	 * 
	 * @param nome The name of the Agenda.
	 */
	
	public Agenda(String nome){
		this.nome = nome;
		this.appuntamenti = new ArrayList<Appuntamento>();
		
	}	
	

	/**
	 * Adds an appointment to the Agenda.
	 * 
	 * @param appuntamento The appointment to be added.
	 * @throws IllegalArgumentException if the appointment overlaps with another appointment in the Agenda.
	 */
	
	public void aggiungiAppuntamento(Appuntamento appuntamento) {
		
		if(!controlloSovrapposizioni(appuntamento)) 
			throw new IllegalArgumentException("\nL'appuntamento che vuoi aggiungere si sovrapporebbe con uno gi� esistente");
	    this.appuntamenti.add(appuntamento);
	    System.out.println("Appuntamento aggiunto con successo!");
	}
	
	/**
	 * Checks if the given appointment overlaps with any other appointment in the Agenda.
	 * 
	 * @param appuntamento The appointment to be checked.
	 * @return true if there is no overlap, false otherwise.
	 */
	
	public boolean controlloSovrapposizioni(Appuntamento appuntamento) {
			
		LocalDate appuntamentoData = appuntamento.getData();
        LocalTime appuntamentoOra = appuntamento.getOrario();
        LocalTime appuntamentoFine = appuntamentoOra.plusMinutes(appuntamento.getDurata());
        
		for (Appuntamento a : appuntamenti) {
	        
	        LocalDate aData = a.getData();
	        LocalTime aOra = a.getOrario();
	        LocalTime aFine = aOra.plusMinutes(a.getDurata());
	        
	        if (appuntamentoData.equals(aData) && ((appuntamentoOra.isAfter(aOra) && appuntamentoOra.isBefore(aFine)) || (appuntamentoFine.isAfter(aOra) && appuntamentoFine.isBefore(aFine)))) 
	        	return false;
	    }
		return true;
	}	
	
	/**

	Modifies an appointment.

	@param appuntamento the appointment to be modified
	*/
	
	public void modificaAppuntamento(Appuntamento appuntamento) {

		int scelta;
        while (true) {
            System.out.println("\nCosa vuoi modificare? Scrivi il numero relativo alla correzione che vuoi fare:\n1 Data\n2 Orario\n3 Durata\n4 Nome della persona\n5 Luogo\n");
            if (sc.hasNextInt()) {
                scelta = sc.nextInt();
                sc.nextLine();
                if (scelta >= 1 && scelta <= 5) {
                    break;
                }
                else
                	System.out.println("\nIl numero deve essere compreso tra 1 e 5");
            } else {
                System.out.println("\nInserire un numero intero valido");
                sc.next();
            }
        }
		
		if(scelta == 1) {
			String data;
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			LocalDate vecchia_data = appuntamento.getData(); 

			
			do {
				appuntamento.setData(vecchia_data);
				System.out.println("\nScrivi la nuova data dell'appuntamento nel formato gg-mm-aaaa");
				data = sc.nextLine();
				
				if(!data.matches("\\d{2}-\\d{2}-\\d{4}")) {
					System.out.println("\nDevi inserire la data nel formato gg-mm-aaaa");
					continue;
				}
				appuntamento.setData(LocalDate.parse(data, formatter));
				if(!controlloSovrapposizioni(appuntamento))
					System.out.println("\nIl cambio di data che stai effettuando sovrapporrebbe l'appuntamento con uno gi� esistente");
				
			}while(!data.matches("\\d{2}-\\d{2}-\\d{4}") || !controlloSovrapposizioni(appuntamento));
			
			System.out.println("\nData cambiata con successo");
		}
		else if(scelta == 2) {
			String orario;
	        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("HH:mm");
	        LocalTime vecchio_orario = appuntamento.getOrario();
			
	        do {
	        	appuntamento.setOrario(vecchio_orario);
	        	System.out.println("\nScrivi la nuova ora dell'appuntamento nel formato hh:mm");
	        	orario = sc.nextLine();
	        	
	        	if(!orario.matches("^([01][0-9]|2[0-3]):[0-5][0-9]$")) {
					System.out.println("\nDevi inserire l'orario nel formato hh:mm");
					continue;
				}
	        	
	        	appuntamento.setOrario(LocalTime.parse(orario, formatter2));
	        	if(!controlloSovrapposizioni(appuntamento))
					System.out.println("\nIl cambio di orario che stai effettuando sovrapporrebbe l'appuntamento con uno gi� esistente");
				
	        }while(!orario.matches("^([01][0-9]|2[0-3]):[0-5][0-9]$") || !controlloSovrapposizioni(appuntamento));
	        
	        System.out.println("\nOrario cambiato con successo");
		}
		
		else if (scelta == 3) {
			int durata;
			int durata_vecchia = appuntamento.getDurata();
			
			do{
				appuntamento.setDurata(durata_vecchia);
				
				while (true) {
		            System.out.println("\nScrivi la nuova durata dell'appuntamento");
		            if (sc.hasNextInt()) {
		                durata = sc.nextInt();
		                sc.nextLine();
		                break;
		            }
		            else {
		                System.out.println("\nInserire un numero intero valido");
		                sc.next();
		            }
		        }
			 
				appuntamento.setDurata(durata);
	        	if(!controlloSovrapposizioni(appuntamento))
					System.out.println("\nIl cambio di durata dell'appuntamento che stai effettuando sovrapporrebbe l'appuntamento con uno gi� esistente");
				
			}while(!controlloSovrapposizioni(appuntamento));
		
		System.out.println("\nDurata cambiata con successo");
		}
		
		else if (scelta == 4) {
			
			System.out.println("\nScrivi il nuovo nome della persona dell'appuntamento");
			String persona = sc.nextLine();
			appuntamento.setNome_persona(persona);
			System.out.println("\nNome della persona cambiato con successo");
		}
		
		else if (scelta == 5) {
			
			System.out.println("\nScrivi il nuovo luogo dell'appuntamento");
			String luogo = sc.nextLine();
			appuntamento.setLuogo(luogo);
			System.out.println("\nLuogo cambiato con successo");
		}
		
	}
	
	/**
	 * The cercaAppuntamentoData method searches for appointments by date.
	 *
	 * @param data_str a string representation of a date in the format "dd-MM-yyyy"
	 */
	
	public void cercaAppuntamentoData(String data_str) {
		
		LocalDate data = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		try {
			data = LocalDate.parse(data_str, formatter);
		}catch(IllegalArgumentException e) {
			System.out.println("\nLa data che hai inserito non � nel formato gg-mm-aaaa");
		}
		
		for(Appuntamento a : appuntamenti) {
			if(a.getData().equals(data)) {
				System.out.println(a);
			}
		}
	}
	
	/**
	 * The cercaAppuntamentoPersona method searches for appointments by person.
	 *
	 * @param persona the name of the person for whom the appointments should be searched
	 */
	
	public void cercaAppuntamentoPersona(String persona) {
		
		for (Appuntamento a : appuntamenti) {
			if(a.getPersona().equals(persona)) {
				System.out.println(a);
			}
		}
	}
	
		
	public String getNome() {
		return nome;
	}

	public ArrayList<Appuntamento> getAppuntamenti() {
		return appuntamenti;
	}

	@Override
	public String toString() {
		return "Agenda [nome=" + nome + ", appuntamenti=" + appuntamenti + "]";
	}


	@Override
	public Iterator iterator() {
		return appuntamenti.iterator();
	}
}
