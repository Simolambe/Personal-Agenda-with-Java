package progetto_agenda;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.LocalTime;

/**

This class represents an appointment. It contains information about the date, time, duration, name of the person, and location of the appointment.
@author Lamberti Simone
*/


public class Appuntamento {

    private LocalDate data;
    private LocalTime orario;
    private int durata;
    private String nome_persona;
    private String luogo;
	
    /**
     * Creates a new appointment with the given date, time, duration, name, and location
     * 
     * @param data The date of the appointment in the format "dd-MM-yyyy"
     * @param orario The time of the appointment in the format "HH:mm"
     * @param durata The duration of the appointment in minutes
     * @param nome The name of the person for the appointment
     * @param luogo The location of the appointment
     */
	
	public Appuntamento(String data, String orario, int durata, String nome, String luogo) {
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("HH:mm");
		this.data = LocalDate.parse(data, formatter);
        this.orario = LocalTime.parse(orario, formatter2);
	    this.durata = durata;
	    this.nome_persona = nome;
	    this.luogo = luogo;
	}
	
	
    public LocalDate getData() {
		return data;
	}


	public LocalTime getOrario() {
		return orario;
	}

	public int getDurata() {
		return durata;
	}

	public String getPersona() {
		return nome_persona;
	}

	public String getLuogo() {
		return luogo;
	}
	
	public void setNome_persona(String nome_persona) {
		this.nome_persona = nome_persona;
	}


	public void setLuogo(String luogo) {
		this.luogo = luogo;
	}


	public void setData(LocalDate data) {
		this.data = data;
	}


	public void setOrario(LocalTime orario) {
		this.orario = orario;
	}


	public void setDurata(int durata) {
		this.durata = durata;
	}


	@Override
	public String toString() {
		return "Appuntamento [data=" + data + ", orario=" + orario + ", durata=" + durata + ", nome_persona="
				+ nome_persona + ", luogo=" + luogo + "]";
	}

}
