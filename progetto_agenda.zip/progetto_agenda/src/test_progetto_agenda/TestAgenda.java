package test_progetto_agenda;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Test;

import progetto_agenda.Agenda;
import progetto_agenda.Appuntamento;
import progetto_agenda.GestoreAgende;


/**

The TestAgenda class contains JUnit test cases for testing the functionality of the Agenda and GestoreAgende classes.
*/

class TestAgenda {	
	
	/**
	 * Test method for creation of an appointment.
	 * Verifies if the appointment object is correctly created with the specified parameters.
	 */
	
	@Test 
	void testCreazioneAppuntamento() {	
		Appuntamento a = new Appuntamento("02-02-2023","10:00",60,"Marco","Vercelli");
		assertEquals(LocalDate.parse("02-02-2023", DateTimeFormatter.ofPattern("dd-MM-yyyy")), a.getData());
		assertEquals(LocalTime.parse("10:00", DateTimeFormatter.ofPattern("HH:mm")), a.getOrario());
		assertEquals(60, a.getDurata());
		assertEquals("Marco", a.getPersona());
		assertEquals("Vercelli", a.getLuogo());	
		} 
	
	/**
	 * Test method for creation of an agenda.
	 * Verifies if the agenda object is correctly created with the specified name.
	 */
	
	
	@Test
	void testCreazioneAgenda() {
		
		Agenda a = new Agenda("agenda_lavoro");
		assertEquals("agenda_lavoro",a.getNome());
		assertNotNull(a.getAppuntamenti());
	}
	
	
	/**

	The testControlloSovrapposizioni method tests the functionality of the controlloSovrapposizioni method in the Agenda class.
	It creates an instance of the Agenda class and two instances of the Appuntamento class.
	It tests if the method returns the correct result for two appointments that do not overlap and for two appointments that overlap.
	*/

	@Test
	void testControlloSovrapposizioni() {
		Agenda a = new Agenda("Agenda_lavoro");
		Appuntamento a1 = new Appuntamento("04-02-2023","12:30",30,"Marco Rossi","Vercelli");
		Appuntamento a2 = new Appuntamento("05-02-2023","10:30",45,"Luca Bianchi","Novara");
		Appuntamento a3 = new Appuntamento("04-02-2023","12:00",50,"Andrea Gialli","Vercelli");
		a.aggiungiAppuntamento(a1);
		assertEquals(true,a.controlloSovrapposizioni(a2));
		assertEquals(false,a.controlloSovrapposizioni(a3));
	}
	
	
	/**

	The testEccezioneAggiungiAppuntamento method tests the exception handling in the Agenda class when adding an appointment.
	It creates an instance of the Agenda class and two instances of the Appuntamento class.
	It adds the first appointment to the agenda and tests if the exception is thrown when adding the second appointment that overlaps with the first one.
	*/
	
	@Test
	void testEccezioneAggiungiAppuntamento(){
		Agenda a = new Agenda("Agenda_lavoro");
		Appuntamento a1 = new Appuntamento("04-02-2023","12:30",30,"Marco Rossi","Vercelli");
		Appuntamento a2 = new Appuntamento("04-02-2023","12:00",50,"Andrea Gialli","Vercelli");
		a.aggiungiAppuntamento(a1);
		IllegalArgumentException e = assertThrows(IllegalArgumentException.class, ()->{
		
				a.aggiungiAppuntamento(a2);
		});
		assertEquals(e.getMessage(),"\nL'appuntamento che vuoi aggiungere si sovrapporebbe con uno gi� esistente");
	}
	
	/**

	The testEccezioneAggiungiAgenda method tests the exception handling in the GestoreAgende class when adding an agenda.
	It creates an instance of the GestoreAgende class and adds an agenda with a specific name.
	It tests if the exception is thrown when adding another agenda with the same name.
	*/
	
	@Test
	void testEccezioneAggiungiAgenda(){
		Agenda a1 = new Agenda("Agenda_lavoro");
		GestoreAgende a = new GestoreAgende();
		a.aggiungiAgenda("agenda_lavoro");
		IllegalArgumentException e = assertThrows(IllegalArgumentException.class,()->{
			a.aggiungiAgenda("agenda_lavoro");
		});
		assertEquals(e.getMessage(),"\nNon � possibile aggiungere un'agenda con lo stesso nome");
	}
	
	/**

	The testEccezioneEliminaAgenda method tests the exception handling in the GestoreAgende class when deleting an agenda.
	It creates an instance of the GestoreAgende class and adds an agenda with a specific name.
	It tests if the exception is thrown when trying to delete an agenda that doesn't exist.
	*/
	
	@Test
	void testEccezioneEliminaAgenda(){
		Agenda a1 = new Agenda("Agenda_lavoro");
		GestoreAgende a = new GestoreAgende();
		a.aggiungiAgenda("Agenda_lavoro");
		IllegalArgumentException e = assertThrows(IllegalArgumentException.class,()->{
			a.eliminaAgenda("agenda");
		});
		assertEquals(e.getMessage(),"\nL'agenda che vuoi eliminare non esiste, controlla di aver inserito il nome corretto"); 
	}
	
	/**

	This method tests the "scriviSuFile" method of the GestoreAgende class.
	It creates an instance of Agenda and GestoreAgende, and then calls the "scriviSuFile" method with the specified file name and Agenda instance as arguments.
	It then checks if the file exists and passes the test if it does.
	@throws IOException if an I/O error occurs
	*/
	
	@Test
	void testScriviSuFile() {
		Agenda a = new Agenda("Agenda_lavoro");
		GestoreAgende g = new GestoreAgende();
		try {
            g.scriviSuFile("agenda.txt", a);
            File file = new File("agenda.txt");
            assertTrue(file.exists());
        } catch (IOException e) {
        	System.out.println(e.getMessage());
        }
	}
	
	/**

	Tests the exception thrown by the method "leggiDaFile" in the "GestoreAgende" class.
	The method should throw an exception if the file name entered does not exist.
	The exception message should be "Il nome del file che hai inserito non esiste"
	*/
	
	@Test
	void testEccezioneLeggiDaFile() {
		Agenda a = new Agenda("Agenda_lavoro");
		GestoreAgende g = new GestoreAgende();
		IllegalArgumentException e = assertThrows(IllegalArgumentException.class,()->{
			g.leggiDaFile("agenda");
		});
		assertEquals(e.getMessage(),"\nIl nome del file che hai inserito non esiste");
	}
	
}
